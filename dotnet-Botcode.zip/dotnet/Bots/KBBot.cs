﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
//using Plugins;

using System.IO;
using AdaptiveCards;
using Microsoft.SemanticKernel.Connectors.OpenAI;
using Newtonsoft.Json;

namespace GenAIBot.Bots
{
    public class KBBot<T> : StateManagementBot<T> where T : Dialog
    {
        private readonly string _instructions;
        //private readonly string _welcomeMessage;
        private readonly string _endpoint;
        private readonly string _deploymentChatName;
        private readonly string _aoApikey;
        private readonly AzureSearchChatDataSource _chatDataSource;
        private readonly string _searchApiKey;
        private readonly string _searchEndpoint;
    

        public KBBot(IConfiguration config, ConversationState conversationState, UserState userState, AzureOpenAIClient aoaiClient, AzureSearchChatDataSource chatDataSource, T dialog)
            : base(config, conversationState, userState, dialog)
        {
            _instructions = config["LLM_INSTRUCTIONS"];
            //_welcomeMessage = "Hello and welcome to the Knowledgebase Bot!";//config.GetValue("LLM_WELCOME_MESSAGE", "Hello and welcome to the Semantic Kernel Bot Dotnet!");
            _endpoint = config["AZURE_OPENAI_API_ENDPOINT"];
            _deploymentChatName = config["AZURE_OPENAI_DEPLOYMENT_NAME"];
            _aoApikey=config["AZURE_OPENAI_API_KEY"];
            _searchApiKey = config["AZURE_SEARCH_API_KEY"]; 
            _searchEndpoint = config["AZURE_SEARCH_API_ENDPOINT"];
            _searchEndpoint = config["AZURE_SEARCH_INDEX"];
            _chatDataSource = chatDataSource;
        }

        // Modify onMembersAdded as needed
        protected override async Task OnMembersAddedAsync(IList<ChannelAccount> membersAdded, ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            foreach (var member in membersAdded)
            {
                if (member.Id != turnContext.Activity.Recipient.Id)
                {
                    IMessageActivity welcomeMessageActivity = null;
                    string[] paths = [".", "Cards", "welcomeCard.json"];
                    var welcomeCardJson = File.Open(Path.Combine(paths), FileMode.Open);
                    using (var reader = new StreamReader(welcomeCardJson))
                    {
                        var adaptiveCard = reader.ReadToEnd();
                        welcomeMessageActivity = MessageFactory.Attachment(new Microsoft.Bot.Schema.Attachment()
                        {
                            ContentType = AdaptiveCard.ContentType,
                            Content = JsonConvert.DeserializeObject(adaptiveCard),
                        });                
                    }
                    await turnContext.SendActivityAsync(welcomeMessageActivity, cancellationToken);
                    var welcomeText =  "How can I help you today with PLM related queries/service requests?";
                    var promptMessage =GenAIBot.Utils.Utils.GetAdaptiveCardsText(welcomeText);            
                    await turnContext.SendActivityAsync(promptMessage, cancellationToken);
                    
                }
            }
            // Log in at the start of the conversation
            await HandleLogin(turnContext, cancellationToken);
        }

        protected override async Task<bool> OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {            
            // Load conversation state
            var conversationStateAccessors = _conversationState.CreateProperty<ConversationData>(nameof(ConversationData));
            var conversationData = await conversationStateAccessors.GetAsync(
                turnContext, () => new ConversationData()
                {
                    History = new List<ConversationTurn>() {
                        new() { Role = "system", Message = _instructions }
                    }
                });

            // Enforce login
            var loggedIn = await HandleLogin(turnContext, cancellationToken);
            if (!loggedIn)
            {
                return false;
            }

            // Add user message to history
            conversationData.AddTurn("user", turnContext.Activity.Text);

            var kernel = Kernel.CreateBuilder()
            .AddAzureOpenAIChatCompletion(_deploymentChatName, _endpoint, _aoApikey)
            .Build();

            var promptExecutionSettings = new AzureOpenAIPromptExecutionSettings { 
                AzureChatDataSource = _chatDataSource,
                Temperature=0.9,                
                //ToolCallBehavior=ToolCallBehavior.AutoInvokeKernelFunctions
                };

            var history = new ChatHistory();
            foreach (var turn in conversationData.History)
            {
                if (turn.Role == "user")
                {
                    history.AddUserMessage(turn.Message);
                }
                else
                {
                    history.AddAssistantMessage(turn.Message);
                }
            }

            // Run logic to obtain response here
            //var response = "Hello, world!";

            IChatCompletionService chatCompletionService = kernel.GetRequiredService<IChatCompletionService>();

            //var answer = await chatCompletionService.GetChatMessageContentAsync(history, promptExecutionSettings);

            //var response = answer.Content!;

            var answer = await chatCompletionService.GetChatMessageContentAsync(history, promptExecutionSettings, kernel, cancellationToken: cancellationToken);

            var response = answer.ToString();
            
            // Add assistant message to history
            conversationData.AddTurn("assistant", response);

            // Respond back to user
            var responseMessage =Utils.Utils.GetAdaptiveCardsText(response);
            await turnContext.SendActivityAsync(responseMessage, cancellationToken);

            var message = answer?.InnerContent as ChatCompletion;
            var messageContext = message?.GetMessageContext();

            var  citations = messageContext?.Citations;

             if (citations?.Count > 0)
            {
                var citationMessage = MessageFactory.Attachment(Utils.Utils.GetCitationsCard(citations));
                //var responseMessage =GenAIBot.Utils.Utils.GetAdaptiveCardsText(citationMessage);
                await turnContext.SendActivityAsync(citationMessage, cancellationToken);
            }

            // Return true if bot should run next handlers
            return true;
        }
    }
}