﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

namespace GenAIBot.DataModels//Microsoft.BotBuilderSamples
{
    // Defines a state property used to track information about the user.
    public class UserProfile
    {
        public string Name { get; set; }
    }
}
