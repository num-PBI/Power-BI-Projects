// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

namespace GenAIBot.Dialogs//Microsoft.BotBuilderSamples
{
    public class LoginDialog : ComponentDialog
    {
        public readonly BotState _conversationState;
        public readonly string _login_successful_message;
        public readonly string _login_failed_message;
        public LoginDialog(IConfiguration configuration)
            : base(nameof(LoginDialog))
        {
            _login_successful_message = configuration.GetValue<string>("SSO_MESSAGE_SUCCESS", "Login success");
            _login_failed_message = configuration.GetValue<string>("SSO_MESSAGE_FAILED", "Login failed");
            AddDialog(new OAuthPrompt(
                nameof(OAuthPrompt),
                new OAuthPromptSettings
                {
                    ConnectionName = configuration.GetValue<string>("SSO_CONFIG_NAME"),
                    Text = configuration.GetValue<string>("SSO_MESSAGE_TITLE"),
                    Title = configuration.GetValue<string>("SSO_MESSAGE_PROMPT"),
                    Timeout = 300000, // User has 5 minutes to login (1000 * 60 * 5)
                    EndOnInvalidMessage = true
                }));


            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), new WaterfallStep[]
            {
                PromptStepAsync,
                LoginStepAsync
            }));

            // The initial child Dialog to run.
            InitialDialogId = nameof(WaterfallDialog);
        }

        private async Task<DialogTurnResult> PromptStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            return await stepContext.BeginDialogAsync(nameof(OAuthPrompt), null, cancellationToken);
        }

        private async Task<DialogTurnResult> LoginStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // Get the token from the previous step.
            var tokenResponse = (TokenResponse)stepContext.Result;
            if (tokenResponse?.Token != null)
            {
                try
                {
                    await stepContext.Context.SendActivityAsync(_login_successful_message);
                    return await stepContext.EndDialogAsync(cancellationToken: cancellationToken);
                }
                catch { }

            }

            await stepContext.Context.SendActivityAsync(_login_failed_message);
            return await stepContext.EndDialogAsync(cancellationToken: cancellationToken);
        }
    }
}